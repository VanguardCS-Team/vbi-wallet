# LICENSE

### Theme License

Dashbrd is designed, developed and supported by Simpleqode.

Use of this theme is governed by the license terms of the Bootstrap Themes platform (https://themes.getbootstrap.com/licenses/)

### Questions?

Feel free to reach out to me at yevgenysim+simpleqode@gmail.com if you have any questions.
