# DASHBRD

Dashbrd Theme by Simpleqode.

### Documentation

- Development documentation is available at `src/html/docs/getting-started.html` (or `dist/docs/getting-started.html` after compilation).
- A full list of components is available at `src/html/docs/components.html` (or `dist/docs/components.html` after compilation).

### Getting Started

The steps to compile and begin development are covered in detail in the documentation mentioned above. A quick summary:

- npm install
- npm start

### Support

Feel free to reach out to me at yevgenysim+simpleqode@gmail.com if you have any questions.
