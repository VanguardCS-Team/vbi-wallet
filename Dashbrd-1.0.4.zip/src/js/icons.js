import { createIcons } from 'duo-icons';

createIcons();
