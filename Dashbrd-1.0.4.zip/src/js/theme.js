// Vendor
import './bootstrap';

// Theme
import './autosize';
import './chart';
import './choices';
import './dropzone';
import './flatpickr';
import './icons';
import './inputmask';
import './popover';
import './search';
import './tiptap';
import './tooltip';

// User
import './user';
