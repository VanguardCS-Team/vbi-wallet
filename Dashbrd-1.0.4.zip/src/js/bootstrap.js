import * as bootstrap from 'bootstrap';

// Make available globally for users of the /dist folder
// Feel free to comment this out if you're working in the /src folder
window.bootstrap = bootstrap;
