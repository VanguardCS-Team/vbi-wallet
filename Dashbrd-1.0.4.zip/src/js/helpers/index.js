export { default as getCSSVariableValue } from './getCSSVariableValue';
export { default as getGradient } from './getGradient';
